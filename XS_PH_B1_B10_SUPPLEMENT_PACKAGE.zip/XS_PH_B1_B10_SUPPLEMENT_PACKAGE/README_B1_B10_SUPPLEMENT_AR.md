# حزمة التجارب التكميلية B2/B5/B6/B7/B8/B9/B10

## الغرض وحدود الحزمة

هذه الحزمة مخصصة لاستكمال رد المحكّم على المخطوطة، مع المحافظة على B1-V3 بوصفه الاختبار الأساسي المجمد. لا تعدّل هذه الحزمة ملفات اختيار B1-V3 أو نتائج اختباره. وهي نسخة مستقلة من محرك B1-V3 instrumented مع إضافات محددة للتجارب التكميلية والتحليل.

**لم تُشغّل التجارب التكميلية الكاملة عند إنشاء هذه الحزمة.** تم تنفيذ smoke test صغير للتأكد من عمل المحرك، وملفاته، وbaseline السمعة الجديد. لذلك لا توجد هنا نتائج علمية تكميلية ولا ادعاءات أداء؛ النتائج لا تصبح متاحة إلا بعد تشغيل الأوامر على Kaggle أو بيئة مماثلة.

## مبادئ لا يجوز كسرها

1. لا تعِد تشغيل B1-V3 الأساسي، ولا تغيّر إعداد PH المختار فيه: delta=0.02، threshold=5، beta=0.05، warmup=5، min_block=5.
2. لا تعدّل `B1V3_selection_frozen.json` أو بيانات B1-V3.
3. جميع الاختبارات التكميلية لها مجلدات وبذور ومعايرات مستقلة عن B1-V3.
4. تشغيل B5 هو replay مقصود لأول 48 بذرة من B2_extreme_mild_split عند SNR=-9 dB لحفظ telemetry. لا يُعامل كعينة مستقلة ولا تُضاف صفوفه إلى حجم العينة الاستدلالي لـB2.
5. تظل كل التجارب التكميلية تحليلات إضافية استجابةً للمحكّم؛ لا تُقدّم على أنها جزء من عائلة الاختبارات الأساسية المحددة مسبقًا في B1-V3.
6. أبلغ عن clean PFA المتحقق في الاختبار. quantile=0.95 يستهدف PFA اسميًا 0.05 من بيانات معايرة مستقلة، لكنه لا يفرض تطابق PFA المحقق بين الطرق.

## محتويات التجارب

### B2-A: حساسية نسبة المهاجمين وسقف الاستبعاد

- N=20، 200 جولة، جلسات ثابتة بطول 20.
- SNR: -9 و-6 dB.
- masking attack مع extreme_fraction=0.5.
- rho: 0.1، 0.2، 0.3، 0.4، 0.5.
- exclusion caps: 4، 8، 12 تقريرًا.
- XS-PH وXS-fixed عند K=20 وK=50.
- 96 بذرة اختبار مستقلة لكل خلية.

هذا الجزء يختبر منحنى الحساسية لـrho وأثر السقف. لا يخلط تغيير نسبة الهجوم بتغيير تركيب extreme/mild.

### B2-B: فصل extreme/mild عن rho

- SNR: -9 و-6 dB.
- rho: 0.2 و0.4.
- extreme_fraction: 0، 0.5، 1.0؛ أي mild فقط، خليط 50/50، وextreme فقط.
- cap=8، مع XS-PH وXS-fixed عند K=20 وK=50.
- 96 بذرة اختبار لكل خلية.

تقسيم المجموعات عشوائي داخل المهاجمين (`subgroup_assignment=random`) لتجنب ارتباط subtype بهوية أو فهرس مستخدم بعينه.

### B5: telemetry لهوية المهاجم وقرار الاستبعاد وdisplacement

يشغل telemetry كاملًا لست خلايا (rho=0.2/0.4 × extreme_fraction=0/0.5/1) عند SNR=-9 dB، لأول 48 بذرة من B2-B. يسجل:

- الرتب قبل الاستبعاد (`rank_ascending` و`rank_descending`).
- هوية المستخدم ونوع المهاجم (extreme أو mild).
- residual وconformal p-value وBH وقرار الاستبعاد والاحتفاظ.
- catch حسب subtype وحسب نطاق الرتبة.
- تفكيك displacement إلى الأثر المباشر للمهاجمين extreme/mild وأثر التكوين/الاختيار، بما فيه مساهمة honest high reports.

يُستخدم هذا التشغيل لفهم الآلية فقط. لا يضاعف حجم العينة في تحليل B2.

### B6/B7/B8/B9: المقارنات والمعايرة وغياب الهجوم

يُجرى على SNR=-9/-6 وrho=0.2/0.4 مع masking، إضافة إلى ذراع `attack=none` مستقل. تشمل خطوط المقارنة:

- NoDefense، MLG+TM، MAD، Sn، Qn.
- TTF-CF.
- Trim10/20/40، Median، Huber.
- BetaHistory وBDFHistory.
- OracleRemoval.
- XS-PH وXS-fixed20 وXS-fixed50.

**BDFHistory disclosure:** أُضيف baseline نافذة Beta مستوحى من مكوّن السمعة في Wu et al. (2024), *Electronics*, 13, 3386, DOI: 10.3390/electronics13173386. يحوّل هذا التكييف التقارير المستمرة إلى مؤشر اتساق peer-relative مبني على LOO median/MAD، ويقدّر موثوقية كل مستخدم بنافذة Beta متحركة. لكنه لا يعيد تنفيذ آلية المقال كاملة، التي تتضمن بيانات تسليم، وتقييمات موجبة/سالبة موزونة، وترتيبًا ودمجًا متسلسلًا لنسبة الترجيح. لذلك يجب وصفه في المخطوطة بأنه **BDF-inspired study adaptation**، لا BDF reproduction.

**OracleRemoval:** عتبة OracleRemoval تُعاير على H0 نظيف بعد إزالة مجموعة عشوائية من L تقارير نظيفة في كل بذرة معايرة، حيث L يساوي عدد التقارير التي تقابل rho. في الاختبار، يُزيل Oracle هويات المهاجمين المعروفة. هو حد مرجعي مثالي وليس كاشفًا عمليًا.

B8 يحتفظ بإحصاء الدمج الخام لكل جولة لإنتاج ROC/AUC وقياس PD@FPR=0.05 من ROC الاختبار. هذا التحليل مستقل عن التشغيل عند العتبة المعايرة؛ أبلغ الاثنين منفصلين.

B9 يتضمن `attack=none` صراحةً ويبلغ PDclean وPFAclean وJclean. هذا مختلف عن شرط `fixed:200` الذي يختبر غياب حدود الجلسات وليس غياب الهجوم.

### B10: persistence stress

- SNR=-9/-6 dB، rho=0.2/0.4، masking وno-attack.
- persistence w=0، 0.5، 0.9.
- 96 بذرة اختبار، والجلسات ثابتة بطول 20.
- score banks الخاصة بـXS تُدرّب عند w=0، وتُعاد معايرة عتبات التشغيل النظيفة لكل قيمة w.

نموذج persistence المستخدم في محرك التجربة:

\[
z_i=\sqrt{w}\,z_{i,\mathrm{persistent}}+\sqrt{1-w}\,z_{i,\mathrm{session}},
\]

للمكونات المعيارية في مجال log-gain، مع مزج عدم يقين الضوضاء بالطريقة الموثقة في `xs_experiment_v2.py` وقصه عند حدود نموذج عدم اليقين. ينبغي وصف ذلك بوضوح وعدم تفسيره باعتباره Markov ON/OFF لحالة PU.

## مجموعات البذور

| التشغيل | score calibration | threshold calibration | test |
|---|---:|---:|---:|
| B1-V3 الأساسي المجمد | 72000–72149 | 72200–72349 | 73000–73095 |
| B2 rho/cap | 84000–84149 | 84200–84349 | 85000–85095 |
| B2 extreme/mild | 84400–84549 | 84600–84749 | 85100–85195 |
| B5 telemetry replay | نفس B2 extreme/mild | نفس B2 extreme/mild | 85100–85147 (جزء من B2) |
| B6–B9 baselines | 86000–86149 | 86200–86349 | 87000–87095 |
| B10 persistence | 88000–88149 | 88200–88349 | 89000–89095 |

جميع pools التكميلية مستقلة عن B1-V3، كما أن test pools بين التجارب الاستدلالية التكميلية مستقلة. B5 وحده يعيد تشغيل جزءًا من B2 intentionally.

## التنفيذ على Kaggle

ارفع `XS_PH_B1_B10_SUPPLEMENT_PACKAGE.zip` إلى Kaggle Dataset، ثم في Notebook:

```python
import zipfile
from pathlib import Path

ZIP = next(Path('/kaggle/input').rglob('XS_PH_B1_B10_SUPPLEMENT_PACKAGE.zip'))
WORK = Path('/kaggle/working/XS_PH_B1_B10_SUPPLEMENT_PACKAGE')
WORK.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(ZIP) as z:
    z.extractall('/kaggle/working')
print(WORK)
```

شغّل أولًا خطة الأوامر فقط:

```bash
python /kaggle/working/XS_PH_B1_B10_SUPPLEMENT_PACKAGE/run_supplement_b1_b10.py --plan-only
```

ثم شغّل كل مرحلة منفصلة حتى يمكن استئناف العمل والتحقق من كل مجلد:

```bash
python /kaggle/working/XS_PH_B1_B10_SUPPLEMENT_PACKAGE/run_supplement_b1_b10.py --run B2_rho_cap
python /kaggle/working/XS_PH_B1_B10_SUPPLEMENT_PACKAGE/run_supplement_b1_b10.py --run B2_extreme_mild_split
python /kaggle/working/XS_PH_B1_B10_SUPPLEMENT_PACKAGE/run_supplement_b1_b10.py --run B5_telemetry_replay
python /kaggle/working/XS_PH_B1_B10_SUPPLEMENT_PACKAGE/run_supplement_b1_b10.py --run B6_B7_B8_B9_comparators
python /kaggle/working/XS_PH_B1_B10_SUPPLEMENT_PACKAGE/run_supplement_b1_b10.py --run B10_persistence
```

المخرج الافتراضي: `/kaggle/working/XS_PH_B1_B10_SUPPLEMENT`.

بعد اكتمال كل التشغيلات:

```bash
python /kaggle/working/XS_PH_B1_B10_SUPPLEMENT_PACKAGE/analyze_supplement_b1_b10.py \
  --root /kaggle/working/XS_PH_B1_B10_SUPPLEMENT

python /kaggle/working/XS_PH_B1_B10_SUPPLEMENT_PACKAGE/validate_supplement.py \
  --root /kaggle/working/XS_PH_B1_B10_SUPPLEMENT
```

إذا فشل أي تشغيل، لا تعِد تشغيله فوق مجلد جزئي. اختر `--outroot` جديدًا أو افحص المخرجات قبل حذفها. سكربت التشغيل يرفض الإلحاق إلى مجلد غير فارغ.

## تفسير إحصائي ملزم

- B1-V3 يبقى عائلة الاختبارات الأساسية المجمدة الوحيدة.
- نتائج B2 وB5 وB6–B10 تُقدّم كتحليلات تكميلية استجابةً للمحكّم.
- لا تستخدم عدم الدلالة لإثبات التكافؤ.
- لا تدّعِ أن BetaHistory أو BDFHistory يعيد تنفيذ ورقة [7] حرفيًا.
- لا تسمِّ PD@FPR=0.05 من ROC الاختبار عتبة تشغيلية معايرة مسبقًا؛ أبلغها باعتبارها نقطة من منحنى ROC على درجات الاختبار، وبجانبها PFA الفعلي عند عتبة المعايرة المستقلة.
- لا تخلط `attack=none` مع `fixed:200`.
- يجب الإبلاغ عن الإنذارات الكاذبة للتقسيم عند no-change، وعن حدود التعميم المرتبطة بحجم الشبكة N=20 وافتراضات نموذج الإبلاغ.

## ملفات الحزمة

- `run_supplement_b1_b10.py`: مشغّل التجارب وفق البروتوكول المجمد.
- `run_xs_study_v2.py`: محرك توليد وتقييم التجارب، منسوخ إلى هذه الحزمة المستقلة مع baseline BDFHistory الموثق.
- `analyze_supplement_b1_b10.py`: تلخيص B2/B5/B6/B7/B8/B9/B10.
- `validate_supplement.py`: فحص اكتمال التشغيل، والتكرار، وفصل البذور، وعلاقة replay.
- `supplement_protocol.json`: الإعدادات والبذور والتمييز بين الاختبارات الأساسية والتكميلية بصيغة قابلة للقراءة آليًا.
