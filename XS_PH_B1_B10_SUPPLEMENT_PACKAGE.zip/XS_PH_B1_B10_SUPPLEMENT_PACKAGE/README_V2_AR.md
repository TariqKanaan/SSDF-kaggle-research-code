# حزمة V2 الموثّقة لتجارب XS (استجابة B1–B9)

هذه نسخة تجريبية جديدة من مولّد المحاكاة ومسار التقييم، صُممت لتسجيل البيانات اللازمة لملاحظات المحكّم B1–B9. **لا تستبدل ملفات V1 ولا تعدّل نتائجها**. شغّلها في مجلد نتائج مستقل.

## 1. ما الذي تسجّله النسخة؟

| الملف | محتواه |
|---|---|
| `v2_user_observations.csv.gz` | كل تقرير خام لكل مستخدم وجولة: `user_id`، هوية benign/malicious، فئة attacker (extreme/mild/upward/downward)، الرتبة قبل أي استبعاد، وحالة حدود الجلسة. |
| `v2_user_decisions.csv.gz` | سجل القرار لكل pipeline ومستخدم وجولة: residual، مصدر تعريف residual، conformal p-value ومصدرها، evidence score، BH flag، الاستبعاد/الاحتفاظ، وHuber weight عند انطباقه. |
| `v2_attacker_rank_distribution.csv.gz` | ملخص توزيع رتب extreme/mild/benign من التقارير الخام قبل الاستبعاد، مع بقاء ملف الملاحظات الخام لإعادة التحليل حسب الجولة والبذرة. |
| `v2_pipeline_round.csv.gz` | إحصاء الدمج والقرار النهائي وحدود الكتل لكل pipeline وجولة وتسلسل H0/H1. |
| `v2_session_boundaries.csv.gz` | حدود الجلسات الحقيقية التي استخدمها مولّد المحاكاة. |
| `v2_block_boundaries.csv.gz` | حدود PH والكتل الثابتة المكتشفة، بداية ونهاية وطول كل block. |
| `v2_displacement.csv.gz` | تفكيك إزاحة متوسط H0 المدمج إلى أثر التلاعب المباشر وأثر تغيّر مجموعة التقارير المحتفظ بها. |
| `v2_seed_level.csv.gz` | PD/PFA/J للهجوم وللحالة النظيفة، FFRclean، وCatch الإجمالي والمنفصل إلى extreme/mild لكل بذرة، مع `persistence_w`. |
| `v2_seed_count_plan_from_v1.csv` | تقدير تخطيطي لعدد بذور الاختبار بناءً على الفروق الزوجية في نتائج V1. |
| `v2_thresholds.csv.gz` | عتبات كل pipeline مع حجم مجموعة المعايرة. عتبة Oracle منفصلة حسب عدد التقارير المحذوفة و`persistence_w`. |
| `v2_oracle_calibration_subsets.csv.gz` | هويات التقارير النظيفة التي أزيلت في كل بذرة معايرة لـ OracleRemoval، لضمان إمكانية إعادة إنتاج subset ومعرفة حجمه. |
| `v2_calibration_scores.csv.gz` | درجات المعايرة الخام على مستوى البذرة والجولة المستخدمة لحساب العتبة. |
| `v2_threshold_transfer_diagnostics.csv.gz` | يقارن PFAclean على بيانات الاختبار عند عتبة معايرة w=0 وعند العتبة المعايرة لنفس persistence_w؛ لتشخيص انتقال العتبة وتضخم NoDefense. |
| `v2_score_bank_sizes.csv.gz` | أحجام buckets في بنوك conformal، وعدد بذور وجولات المعايرة. |
| `v2_aggregate.csv.gz` | المتوسط والانحراف المعياري وعدد البذور لكل شرط وطريقة. |
| `v2_manifest.json` و`v2_seed_ledger.json` | الإعدادات والبذور ومعلومات التشغيل وبصمات ملفات الكود عند بداية التشغيل. |
| `v2_output_sha256.json` | بصمات الملفات الناتجة بعد انتهاء التشغيل. |

كل الملفات الكبيرة مضغوطة بصيغة gzip، ويمكن قراءتها مباشرة باستخدام `pandas.read_csv("file.csv.gz")`.

## 2. التثبيت والتحقق

تحتاج إلى Python 3.10+ ومكتبات NumPy وPandas وSciPy وscikit-learn:

```bash
pip install -r requirements.txt
python validate_v2.py
```

اختبار التحقق يقوم بما يلي:

- يتأكد أن `fixed:20` مع تقسيم المهاجمين `legacy_sorted` يولّد نفس سلاسل H0/H1 التي يولّدها مولّد V1، bit-for-bit.
- يتحقق من أطوال الجلسات وتقسيم extreme/mild.
- يقارن مخرجات XS العددية في V2 مع تنفيذ V1 المضمّن في الحزمة.
- يعيد إنتاج مولّد persistence القديم عند `w=0.5` مع `fixed:20` و`legacy_sorted` للتحقق من التوافق.

## 3. تجربة اختبار قصيرة للتأكد من ملفات المخرجات

```bash
SSDF_SCORE_CAL_ROUNDS=30 SSDF_TAU_CAL_ROUNDS=30 python run_xs_study_v2.py \
  --out v2_smoke \
  --snrs=-9 --rhos=0.2 --attacks=masking,none \
  --session-specs='fixed:20' \
  --extreme-fractions=0.5 --subgroup-assignment=random \
  --caps=8 --fixed-blocks=20 \
  --test-count=2 --score-cal-count=3 --tau-cal-count=3 \
  --rounds=40 \
  --pipelines='NoDefense,XS-PH,XS-fixed20,Trim10,Trim20,Huber,BetaHistory,OracleRemoval'

python analyze_v2.py --results v2_smoke
```

هذا اختبار برمجي فقط، وليس حجماً كافياً للاستدلال العلمي.

## 4. تجربة B1: عزل أثر Page–Hinkley

استخدم الأطوال المختلفة للجلسة، مع أطوال كتل ثابتة مستقلة عنها:

```bash
python run_xs_study_v2.py \
  --out v2_B1 \
  --snrs=-9,-6 --rhos=0.2 --attacks=masking \
  --session-specs='fixed:13;fixed:20;fixed:30;fixed:50;random:13,20,30,50' \
  --extreme-fractions=0.5 --subgroup-assignment=random \
  --caps=8 --fixed-blocks=10,13,20,30,50 \
  --test-count=400 --score-cal-count=100 --tau-cal-count=100 \
  --pipelines='NoDefense,Trim10,Trim20,Trim40,Median,Huber,BetaHistory,XS-PH,XS-fixed,OracleRemoval'

python analyze_v2.py --results v2_B1
```

- `XS-fixed` ينشئ XS-fixed10/13/20/30/50، ويُخرج `v2_paired_tests.csv.gz` مقارنات B1 المباشرة بين XS-PH وكل XS-fixedK، وكذلك XS-fixed20 مقابل بقية قيم K، باستخدام Wilcoxon وفواصل Bootstrap وWins/Losses/Ties.
- عند كل طول جلسة، تستخدم المقارنات البذور وهويات المهاجمين نفسها. كما تستخدم مولدات ضوضاء الاستشعار H0/H1 streams مستقلة ثابتة عبر جداول الجلسات. لكن سحب حالات القناة/الجلسة وضوضاء الإبلاغ يعتمد على جدول الجلسات؛ لذا المقارنة paired-by-seed وليست common-random-numbers متطابقة لكل مكوّن nuisance.
- `random:13,20,30,50` يسحب طول كل جلسة من هذه المجموعة باستخدام stream مستقل عن ضوضاء الاستشعار.
- `v2_boundary_metrics.csv.gz` يقارن حدود PH بحدود المحاكي الحقيقية ضمن سماحية ±2 جولة افتراضياً. غيّر السماحية في التحليل باستخدام `--boundary-tolerance`، ولا تنتقِ السماحية بعد رؤية النتيجة دون الإفصاح عن ذلك.

## 5. تجارب B2: كثافة المهاجمين والتقسيم والسقف

الأفضل تشغيل شبكة الكثافة ونسبة extreme/mild في وظيفتين منفصلتين لتجنب تضخم عدد الخلايا.

**أ. شبكة كثافة المهاجمين** (مع split ثابت 50% وسقف 8):

```bash
python run_xs_study_v2.py \
  --out v2_B2_density \
  --snrs=-9,-6 --rhos=0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50 \
  --attacks=masking --session-specs='fixed:20' \
  --extreme-fractions=0.5 --subgroup-assignment=random \
  --caps=8 --fixed-blocks=20 --test-count=100 \
  --pipelines='NoDefense,Trim10,Trim20,Trim40,Median,Huber,BetaHistory,XS-PH,XS-fixed20,OracleRemoval'
```

**ب. أثر التقسيم والسقف** (عند كثافات مختارة):

```bash
python run_xs_study_v2.py \
  --out v2_B2_split_cap \
  --snrs=-9,-6 --rhos=0.20,0.40 --attacks=masking \
  --session-specs='fixed:20' \
  --extreme-fractions=0,0.25,0.50,0.75,1 \
  --subgroup-assignment=random --caps=4,8,12 --fixed-blocks=20 \
  --test-count=100 \
  --pipelines='NoDefense,Trim10,Trim20,Trim40,Median,Huber,BetaHistory,XS-PH,XS-fixed20,OracleRemoval'
```

في masking، عدد extreme هو `floor(L * extreme_fraction)`، ويُسجّل العدد الفعلي في كل صف. يعيّن V2 عضويات extreme/mild عشوائياً بواسطة stream منفصل، ويظل ترتيب التقسيم متسقاً عبر قيم split ضمن البذرة والشرط. استخدم `--subgroup-assignment=legacy_sorted` فقط عند إعادة إنتاج تقسيم V1 القديم.

## 6. التحليل الإحصائي B3/B4 وPFA B8

```bash
python analyze_v2.py --results v2_B1 --matched-pfa=0.05 --boundary-tolerance=2
```

ينتج التحليل:

- `v2_paired_tests.csv.gz`: فروق XS-PH مع Trim10/20/40/Median في عائلة RQ1 الأساسية، ومقارنات B1 المباشرة مع XS-fixedK في عائلة مستقلة، وعائلة ثانوية منفصلة لمقارنات J/Catch/FFR مع MLG+TM/MAD/Sn/Qn/ParadigmA/TTF-CF؛ ويتضمن Wins/Losses/Ties وp الخام وHolm-adjusted p.
- `v2_condition_summary_ci.csv.gz`: المتوسط وفاصل ثقة 95% لـ PD/PFA/J وFFRclean وCatch.
- `v2_calibration_precision.csv.gz`: bootstrap على مستوى **seed trajectory** لتقدير عدم يقين عتبة المعايرة. لا يعيد سحب الجولات على أنها عينات مستقلة.
- `v2_threshold_transfer_diagnostics.csv.gz`: يعرض clean PFA باستخدام عتبة w=0 ثم باستخدام العتبة المعايرة تحت w الحالي؛ ويساعد على اختبار ما إذا كان تضخم NoDefense ناتجاً من نقل العتبة بين توزيعين أو يبقى بعد إعادة المعايرة المطابقة.
- `v2_roc_seed_level.csv.gz`: AUC وPD/PFA عند عتبة معايرة تستهدف PFA=0.05.
- `v2_boundary_metrics.csv.gz`: precision/recall وتأخر حدود PH.
- `v2_displacement_aggregate.csv.gz`: تلخيص تفكيك displacement.
- `v2_attacker_rank_distribution.csv.gz`: ملخص الرتب قبل الاستبعاد.

### اختبار الاستمرارية الزمنية وتضخم PFA لـ NoDefense (B8)

يمكن تشغيل خلايا stress مع `w=0,0.5,0.9`:

```bash
python run_xs_study_v2.py \
  --out v2_B8_persistence \
  --snrs=-9,-6 --rhos=0.20 --attacks=none,masking \
  --session-specs='fixed:20' --persistence-ws=0,0.5,0.9 \
  --extreme-fractions=0.5 --caps=8 --fixed-blocks=20 \
  --test-count=400 --score-cal-count=100 --tau-cal-count=100 \
  --pipelines='NoDefense,Trim10,Trim20,Trim40,Median,Huber,BetaHistory,XS-PH,XS-fixed20,OracleRemoval'
python analyze_v2.py --results v2_B8_persistence --matched-pfa=0.05
```

- بنك conformal يُدرّب عند `w=0` عمداً، بينما عتبات القرار `tau` لكل pipeline تُعاد معايرتها على H0 نظيف عند قيمة `w` المقابلة. يحفظ `v2_calibration_scores.csv.gz` درجات المعايرة مع `persistence_w`، وتحفظ `v2_thresholds.csv.gz` العتبات بحسب `w`، وبذلك يمكن فحص تغير achieved PFA لـ NoDefense مباشرةً.
- مولّد الاستمرارية يطابق مولّد V1 القديم عند `w=0.5` و`fixed:20` و`legacy_sorted`، ويحتفظ بتقسيم extreme/mild المستقل عند تشغيل V2.
- الحالة `attack=none` تُنفذ مرة واحدة فقط لكل SNR/session/w، وتُسجل مع `rho=0` و`extreme_fraction=0`؛ لا تتكرر كخلية نظيفة مكررة تحت قيم rho أو split مختلفة.

### تخطيط عدد بذور الاختبار

استخدم V1 عشرين بذرة اختبار وعشر بذور معايرة؛ لا يظهر في سجل التصميم تبرير قوة إحصائية كافٍ لاختيار هذه الأعداد، لذلك يجب التعامل معها كاختيار محدود في النسخة القديمة لا كاختيار محسوب للقوة. العدد الافتراضي الجديد هو 400 بذرة اختبار، و100 بذرة score-calibration، و100 بذرة tau-calibration، مع 200 جولة لكل بذرة معايرة (القيم من `Config`). تقدير 400 مبني على انحرافات الفروق الزوجية في بيانات V1 وحساب تخطيطي محافظ لعائلة من 8 اختبارات، وهو هدف تصميمي تقريبي وليس ضماناً للقوة. أما رفع المعايرة إلى 100 مسار مستقل فيُدعّم بتقدير عدم يقين العتبة عبر cluster bootstrap على مستوى seed trajectory، مع الإبلاغ عن دقة العتبة بدلاً من اعتبار الجولات مستقلة.

لتوثيق تبرير بذور الاختبار من فروق V1 المقترنة:

```bash
python plan_seed_count.py \
  --v1 /path/to/xs_test_seed_level_ALL.csv \
  --out v2_seed_count_plan.csv \
  --delta-j 0.05 --family-size=8
```

في بيانات V1 المرفوعة (20 بذرة)، أعطى الانحراف المعياري الزوجي تقديرات اسمية تتطلب 77–229 بذرة لقوة 80% عند alpha=0.05، لكن عند استخدام Bonferroni المحافظ لعائلة من 8 مقارنات ارتفع النطاق إلى 126–374 بذرة. لذلك 400 بذرة تغطي أعلى تقدير 80% في هذا التخطيط المحافظ. يتطلب هدف 90% ما يصل إلى 470 بذرة. هذه الحسابات تقريبية وتعتمد على SD مقدر من 20 بذرة فقط؛ أبلغ عنها كتحليل تخطيط/حساسية، وليس ضماناً للقوة.

## 7. تعريف المقاييس والتسجيل

- `rank_ascending=1`: أصغر تقرير في الجولة.
- `rank_descending=1`: أكبر تقرير في الجولة.
- الرتب محسوبة من التقارير الخام قبل أي فلترة.
- `residual` في XS هو LOO median/MAD residual الداخلي؛ وفي TTF-CF هو residual الداخلي لـ TTF-CF؛ أما الطرق الأخرى فتحفظ LOO median/MAD كقياس تشخيصي لا يدخل في قرارها.
- `conformal_p_value` يُحفظ لـ XS وTTF-CF؛ ويكون مفقوداً للطرق التي لا تستخدم p-values conformal.
- `excluded` قرار استبعاد التقرير، وليس قرار النظام H0/H1.
- `PFA_clean` هو احتمال قرار النظام H1 على H0_clean.
- `FFR_clean` هو معدل التقارير المستبعدة خطأً على H0_clean.
- `J_clean = PD_clean - PFA_clean`.
- `Catch_extreme` و`Catch_mild` تحسبان من H1_att لكل بذرة.
- `v2_displacement.csv.gz`: الأثر المباشر هو فرق التقرير attacked مقابل clean counterfactual للتقارير المحتفظ بها؛ أثر الاختيار/الإزاحة يقارن مجموعتي التقارير المحتفظ بها في attacked وclean على القيم النظيفة المقابلة. تُعرّف «التقارير النظيفة المرتفعة» بأنها أعلى ربع من التقارير benign في H0_clean داخل الجولة. تحقق من أن `decomposition_error` قريب من الصفر عددياً.

## 8. ملاحظات منهجية وقيود مقصودة

1. `BetaHistory` هو baseline تاريخ/سمعة مبني في هذه الحزمة بصيغة Beta-Bernoulli واضحة، لكنه **تكيف دراسي** وليس ادعاءً بأنه إعادة إنتاج مطابقة لخوارزمية المرجع [7]. قبل وصفه بأنه faithful implementation، يجب مقابلة معادلاته وإعداداته مع النص الكامل للمرجع. Huber هو adaptive robust estimator إضافي.
2. عتبة OracleRemoval تُعاير على H0 نظيف بعد حذف مجموعة عشوائية ثابتة لكل بذرة بحجم `L=round(N*rho)`، وتستخدم هويات المهاجمين الحقيقية في ذراع الاختبار. في خلية `attack=none` يكون `L=0`.
3. يظل نموذج الإبلاغ والنموذج الفيزيائي الأصليان من V1؛ هذه الحزمة لا تعالج تلقائياً كل ملاحظات B10–B12 أو الواقعية الفيزيائية في B11.
4. `v2_manifest.json` يوثق إعدادات وبصمات الكود عند بدء التشغيل، لكنه **ليس بحد ذاته تسجيلًا مسبقاً مستقلاً** ولا يثبت أن كل اختيارات التصميم تمت قبل الاطلاع على نتائج التطوير.
5. لا تستخدم `--skip-user-telemetry` في النسخة النهائية إذا كنت تريد استيفاء B5.
6. `--persistence-ws` يغيّر مولّد عوامل nuisance، وليس فقط metadata. عند الإبلاغ عن B8 يجب وصف عدم تطابق بنك conformal مع الاستمرارية كما هو موضح أعلاه.
7. عند استخدام عدد بذور أقل في شبكة استكشافية كثيفة B2، صرّح أنها exploratory ولا تستخدمها لإثبات تفوق تأكيدي.

## 9. أسماء الملفات المطلوبة داخل الحزمة

تحتوي الحزمة على نسخ الاعتماديات الأصلية (`config_final.py`, `run_final_experiment.py`, `system_model_final.py`, `ttf_cf_final.py`, `paradigm_a_final.py`) حتى تعمل مستقلة عن مجلد V1. لا تستبدل ملفاتك الأصلية بهذه النسخ.
